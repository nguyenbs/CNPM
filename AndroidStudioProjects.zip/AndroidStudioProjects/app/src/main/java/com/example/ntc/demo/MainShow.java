package com.example.ntc.demo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Toast;

public class MainShow extends AppCompatActivity {


    Intent Main = null;
    Intent StartMain = null;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_show);

        Toast.makeText(MainShow.this, "abc", Toast.LENGTH_SHORT).show();


    }



}
