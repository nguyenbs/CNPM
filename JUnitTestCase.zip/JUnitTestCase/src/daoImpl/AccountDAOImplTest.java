package daoImpl;

import static org.junit.Assert.*;

import java.sql.SQLException;

import org.junit.Assert;
import org.junit.Test;


public class AccountDAOImplTest {

	@Test
	public final void testInsertAccount() throws ClassNotFoundException, SQLException {
	}
}
